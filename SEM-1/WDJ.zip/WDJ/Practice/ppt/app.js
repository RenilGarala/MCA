console.log(Array.prototype);
